module.exports = [
  {
    id: 37,
    name: {
      first: "Cristina",
      last: "Buchanan",
    },
  },
  {
    id: 8,
    name: {
      first: "Susanne",
      last: "Lawson",
    },
  },
  {
    id: 10,
    name: {
      first: "Giles",
      last: "Barlow",
    },
  },
  {
    id: 16,
    name: {
      first: "Austin",
      last: "Patton",
    },
  },
  {
    id: 20,
    name: {
      first: "Tate",
      last: "Fletcher",
    },
  },
  {
    id: 25,
    name: {
      first: "Matthews",
      last: "Sanders",
    },
  },
  {
    id: 32,
    name: {
      first: "Ochoa",
      last: "Levy",
    },
  },
  {
    id: 38,
    name: {
      first: "Jaime",
      last: "Carroll",
    },
  },
];
